Usage of ann.cpp (Artificial Neural Network):

Compile with: 

g++ --std=c++11 -o ann ann.cpp

Run with: 

./ann [filename] [number of epochs] [learning rate (negative float)] [first layer size] [second layer size] ... [Regularization: 1 or 0]

"r_functions.h" contains helping functions such as the sigmoid function, cost functions etc.
